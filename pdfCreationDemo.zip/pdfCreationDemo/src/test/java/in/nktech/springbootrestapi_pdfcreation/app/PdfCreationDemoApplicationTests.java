package in.nktech.springbootrestapi_pdfcreation.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfCreationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
