package in.nktech.springbootrestapi_pdfcreation.app.service;

import java.util.List;

import in.nktech.springbootrestapi_pdfcreation.app.model.Student;

public interface StudentService {

	public Student createStudentDetails(Student st);

	public List<Student> getAllStudents();

}
