package in.nktech.springbootrestapi_pdfcreation.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.nktech.springbootrestapi_pdfcreation.app.model.Student;
import in.nktech.springbootrestapi_pdfcreation.app.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService ss;
	
	@PostMapping("/save_Student")
	public Student createStudentDetails(@RequestBody Student st)
	{
		return ss.createStudentDetails(st);
		
	}
}
