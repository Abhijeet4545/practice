package in.nktech.springbootrestapi_pdfcreation.app.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nktech.springbootrestapi_pdfcreation.app.model.Student;
import in.nktech.springbootrestapi_pdfcreation.app.repository.StudentRepository;
import in.nktech.springbootrestapi_pdfcreation.app.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
private	StudentRepository sr;
	@Override
	public Student createStudentDetails(Student st) {
		// TODO Auto-generated method stub
		return sr.save(st);
	}
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return (List<Student>)sr.findAll();
	}

}
