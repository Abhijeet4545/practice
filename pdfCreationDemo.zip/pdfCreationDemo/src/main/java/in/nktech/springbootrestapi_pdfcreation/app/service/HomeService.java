package in.nktech.springbootrestapi_pdfcreation.app.service;

import java.io.ByteArrayInputStream;

public interface HomeService {

	public ByteArrayInputStream createPdf();

}
