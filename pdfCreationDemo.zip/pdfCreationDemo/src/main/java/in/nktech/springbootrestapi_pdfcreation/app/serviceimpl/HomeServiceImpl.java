package in.nktech.springbootrestapi_pdfcreation.app.serviceimpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.CMYKColor;
import com.lowagie.text.pdf.PdfCell;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfTable;
import com.lowagie.text.pdf.PdfWriter;

import in.nktech.springbootrestapi_pdfcreation.app.model.Student;
import in.nktech.springbootrestapi_pdfcreation.app.service.HomeService;
import in.nktech.springbootrestapi_pdfcreation.app.service.StudentService;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private StudentService ss;
	
	@Override
	public ByteArrayInputStream createPdf() {
		
		String title="WELCOME TO CJC....!!";
		
		Date date=new Date();
		
		DateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
		
		String formatedDate=dateFormat.format(date);
		
		String to="Date:-"+formatedDate+"\nTo:-Admin";
		
		String text="               This is the Fees Status OF Current Month....!!!    ";
		
             List<Student>	stus=	ss.getAllStudents();
		
             String thanksText="Regards...!!\nThank You,\n Abhjeet Giri";
		
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		Document document=new Document();
		
		PdfWriter.getInstance(document, out);
		
		document.open();
		
		Font titleFont=FontFactory.getFont(FontFactory.HELVETICA_BOLD,25);
		
		titleFont.setColor(CMYKColor.RED);
		Paragraph titlePara=new Paragraph(title,titleFont);
		
		titlePara.setAlignment(Element.ALIGN_CENTER);
		
		document.add(titlePara);
		
		Font toFont=FontFactory.getFont(FontFactory.HELVETICA_BOLD);
		
		Paragraph toPara=new Paragraph(to,toFont);
		
		toPara.setSpacingBefore(40);
		
		
		document.add(toPara);
		
Paragraph textPara=new Paragraph(text);
		
		textPara.setSpacingBefore(10);
		 
		document.add(textPara);
		
		//-----------------------TABLE----------------------------
		
		PdfPTable table=new PdfPTable(5);
		table.setWidths(new int [] {1,4,7,3,3});
		table.setWidthPercentage(100F);
		table.setSpacingBefore(20);
		
		//-----------------CELL----------------------------
		
		PdfPCell headCell=new PdfPCell();
        headCell.setPadding(5);
        headCell.setPaddingLeft(10);
		headCell.setBackgroundColor(CMYKColor.DARK_GRAY);
		Font headCellFont=FontFactory.getFont(FontFactory.HELVETICA_BOLD);
headCellFont.setColor(CMYKColor.WHITE);
		//-----------------Adding Phrase-------------------
		
		headCell.setPhrase(new Phrase("ID",headCellFont));
		table.addCell(headCell);
		headCell.setPhrase(new Phrase("Student Name",headCellFont));
		table.addCell(headCell);
		headCell.setPhrase(new Phrase("EmailId",headCellFont));
		table.addCell(headCell);
		headCell.setPhrase(new Phrase("MobileNumber",headCellFont));
		table.addCell(headCell);
		headCell.setPhrase(new Phrase("Fees Paid",headCellFont));
		table.addCell(headCell);
		

		
		PdfPCell dataCell=new PdfPCell();
		dataCell.setPadding(3);
		dataCell.setBackgroundColor(CMYKColor.PINK);
stus.forEach(s->{
	
	dataCell.setPhrase(new Phrase(String.valueOf(s.getStuId())));
	table.addCell(dataCell);
	dataCell.setPhrase(new Phrase(s.getStuName()));
	table.addCell(dataCell);
	dataCell.setPhrase(new Phrase(s.getStuEmail()));
	table.addCell(dataCell);
	dataCell.setPhrase(new Phrase(String.valueOf(s.getMobileNumber())));
	table.addCell(dataCell);
	dataCell.setPhrase(new Phrase(String.valueOf(s.getFeesPaid())));
	table.addCell(dataCell);
	
});
    document.add(table);
    Paragraph thanksPara=new Paragraph(thanksText);
    thanksPara.setAlignment(Element.ALIGN_LEFT);
    thanksPara.setAlignment(Element.ALIGN_BOTTOM);
    document.add(thanksPara);
    

		document.close();
		
		return new ByteArrayInputStream(out.toByteArray());
	}

}
