package in.nktech.springbootrestapi_pdfcreation.app.controller;

import java.io.ByteArrayInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import in.nktech.springbootrestapi_pdfcreation.app.service.HomeService;

@RestController
public class HomeController {

	@Autowired
private	HomeService hs;
	
	@GetMapping("/getpdf")
	public ResponseEntity<InputStreamResource> getPdfDocument()
	{
		
	ByteArrayInputStream pdfArray=	hs.createPdf();
	HttpHeaders headers=new HttpHeaders();
	headers.add("Content-position", "inline;filename=mypdf.pdf");
	
	return ResponseEntity.ok()
			             .headers(headers)
			             .contentType(MediaType.APPLICATION_PDF)
			             .body(new InputStreamResource(pdfArray));
	
	
	}
}
