package in.nktech.springbootrestapi_pdfcreation.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfCreationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfCreationDemoApplication.class, args);
	}

}
